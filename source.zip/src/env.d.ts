/// <reference types="@astrojs/image/client" />
